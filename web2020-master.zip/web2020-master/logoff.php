<?php
  session_start();
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
</head>
<?php
  session_unset();
  echo "<br><a href='Register-Login.html'>Log off</a>";
?>
<p>Ευχαριστούμε που μας επισκεφθήκατε</p>
</html>

